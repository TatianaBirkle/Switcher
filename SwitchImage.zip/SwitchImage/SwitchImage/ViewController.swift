//
//  ViewController.swift
//  SwitchImage
//
//  Created by Татьяна Биркле on 24.04.2024.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var switcher: UISwitch!
    
    let defaultsettings = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadImage()
        let loadSettings = defaultsettings.bool(forKey: "switcherSettings")
        if loadSettings == false{
            switcher.isOn = false
            loadImage()
        }else{
            switcher.isOn = loadSettings
            loadImage()
        }
    }
    
    @IBAction func switchertapped(_ sender: Any) {
        defaultsettings.set(switcher.isOn, forKey: "switcherSettings")
        loadImage()
    }
   
    func loadImage() {
        imageView.frame = CGRect(x: 40, y: 100, width: view.frame.width - 80, height: view.frame.width - 80)
        if switcher.isOn == false{
            self.view.backgroundColor = .lightBackground
            imageView.image = UIImage(named: "light")
        }else{
            self.view.backgroundColor = .darkBackground
            imageView.image = UIImage(named: "dark")
        }
    }
}
